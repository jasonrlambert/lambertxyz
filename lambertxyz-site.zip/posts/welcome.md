---
title: "Welcome to My New Site"
excerpt: "Here's where I’ll share updates, insights, and ideas."
date: "2025-07-19"
---

Thanks for visiting! Stay tuned for more.
