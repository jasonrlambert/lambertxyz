import React from 'react'
import ReactDOM from 'react-dom/client'
import { BrowserRouter as Router, Routes, Route, NavLink } from 'react-router-dom'
import Home from './Home'
import Blog from './Blog'

const Header = () => {
  return (
    <header style={{
      backgroundColor: "#ffffff",
      borderBottom: "1px solid #ddd",
      padding: "1rem 2rem",
      display: "flex",
      justifyContent: "space-between",
      alignItems: "center"
    }}>
      <h1 style={{ margin: 0, fontSize: "1.5rem", fontWeight: "bold" }}>Jason Lambert</h1>
      <nav>
        <NavLink to="/" end style={({ isActive }) => ({
          marginRight: "1rem",
          textDecoration: isActive ? "underline" : "none",
          color: isActive ? "#007bff" : "#333"
        })}>
          Home
        </NavLink>
        <NavLink to="/blog" style={({ isActive }) => ({
          textDecoration: isActive ? "underline" : "none",
          color: isActive ? "#007bff" : "#333"
        })}>
          Blog
        </NavLink>
      </nav>
    </header>
  );
};

ReactDOM.createRoot(document.getElementById('root')).render(
  <React.StrictMode>
    <Router>
      <Header />
      <main style={{ padding: "2rem", minHeight: "80vh", backgroundColor: "#f9f9f9" }}>
        <Routes>
          <Route path="/" element={<Home />} />
          <Route path="/blog" element={<Blog />} />
        </Routes>
      </main>
    </Router>
  </React.StrictMode>,
)
